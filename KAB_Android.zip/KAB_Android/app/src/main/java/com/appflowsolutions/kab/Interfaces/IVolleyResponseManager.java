package com.appflowsolutions.kab.Interfaces;

public interface IVolleyResponseManager {

    void onResponseSuccess(String response);
    void onResponseError();

}
